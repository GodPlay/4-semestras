clear all
x=[2 4.25 5.25 7.81 9.2 10.6];
y=[7.2 7.1 6 5 3.5 5];
N=length(x);
disp('Reiksmiu lentele yra')
fprintf('*********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('*********************************\n')
for i=1:N
fprintf('|%2G|%14f|%14f|\n',i-1,x(i),y(i)) 
end


taske=4; %Tarpinis taskas.
N=length(x);
%Cia naudoju Lagranzo interpoliacine formule
for i=1:N-1
L(i)=0; %Sumavimui
for k=1:i+1
    c(k)=1; %Daugybai
   for j=1:i+1
      if k~=j %jei k nelygu i
         c(k)=c(k)*((taske-x(j))/(x(k)-x(j)));  %Daugianariu c(taske) reiksmes 
   end 
   end
  L(i)=L(i)+c(k)*y(k); 
end
end
for i=2:N-2
 pakliv(i)=abs(L(i-1)-L(i)) ;
end
fprintf('********************************************************\n')
 fprintf('|N |   Daugianario reiksme|Pak. iv. absoliutiniu didumu| \n') 
 fprintf('********************************************************\n')
 for i=1:N-1
  if i==1 
 pakliv(i)='-';
   else
    pakliv(i)=abs(L(i-1)-L(i)) ;   
    % fprintf('|%2G|%22f|%28f|\n',i,L(i),pakliv(i));
  end
  fprintf('|%2G|%22f|%28c|\n',i,L(i),pakliv(i));
 end
  fprintf('********************************************************\n')
%f i c
  
  
  
  
  