clear all
x=[-2 0 1 2];
y=[3 1 -3 -1];
M=length(x); %x(i) kiekis.  Zinoma galima ir tiesiogiai nurodyti.
N=M-1;  %Daugianario eile.
disp('Reiksmiu lentele yra')
fprintf('**********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('**********************************\n')
for i=1:M
fprintf('|%2G|%14G|%14G|\n',i-1,x(i),y(i)) 
end
fprintf('**********************************\n')
% Pirmiausia apskaiciuojami skirtuminiai santykiai, kur visi isreiskiami 
% per y(k): f(i+1,2)=>f(x(i),x(i+1))=(y(i)-y(i+1))/(x(i)-x(i+1)), kai i>=1, 
%yra pirmos eiles, 
%f(i+1,3)=>f(x(i),x(i+1),x(i+2))=(f(x(i),x(i+1))-f(x(i+1),x(i+2)))/(x(i)-x(i+1))
%yra antros eiles ir t.t.

for k=1:M
   f(k,1)=y(k); 
end 
for j=1:N
    for i=j:N
        f(i+1,j+1)=(f(i,j)-f(i+1,j))/(x(i+1-j)-x(i+1));  
    end
end
%Sukurkime skirtuminiu santykiu lentele, pvz. cia prasideda problemos
 fprintf('****************************************************\n')
 fprintf('|x |y |            f1|            f2|            f3|\n') 
 fprintf('****************************************************\n')
for i=1:M
    for j=i:N
f(i,j+1)='-'; 
    end %rezultatams isvesti naudoju c, kad lenteleje butu panaudoti 
%ir simboliniai kintamieji. Pakeiskite, pavyzdziui, c i G. 
  fprintf('|%2i|%2i|%14c|%14c|%14c|\n',x(i),y(i),f(i,2),f(i,3),f(i,4)) 
end
 fprintf('****************************************************\n')
%
 fprintf('****************************************************\n')
 fprintf('|x |y |            f1|            f2|            f3|\n') 
 fprintf('****************************************************\n')
for i=1:M
    for j=i:N
f(i,j+1)='-'; 
    end 
  fprintf('|%2i|%2i|%14G|%14G|%14G|\n',x(i),y(i),f(i,2),f(i,3),f(i,4)) 
end
 fprintf('****************************************************\n')
