%Sudaromi daugianariai, naudojant kiekvienos eiles daugaianriui atskira algoritma
%1 eiles
clear all
X=[-2 0];
Y=[3 1];
N=length(X);
disp('Reiksmiu lentele yra')
fprintf('**********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('**********************************\n')
for i=1:N
fprintf('|%2G|%14G|%14G|\n',i-1,X(i),Y(i)) 
end
fprintf('**********************************\n')
syms x %jei skaiciuojam daugianariu reiksmes tarpiniuose taskuose, tai sios komandos neprireikai
m=N-1;
for i=1:m
L=0; %Sudeciai
for k=1:i+1
    c=1; %Sandaugai
   for j=1:i+1
      if k~=j %Jei i nelygu j
         c=c*((x-X(j))/(X(k)-X(j))); %Daugianariai c, sudaryti is sandaugu 
      end 
   end
  L=expand(L+c*Y(k)); %Daugianario L galutinis realizavimas.
end
end
fprintf('%G eiles daugianaris',m)
pretty(L)
%Grafiskai 
figure,
ezplot(L,[X(1)-1,X(N)+2]), hold on, 
plot(X,Y,'bo','MarkerFaceColor','b'), hold off, 
xlabel(' x '), ylabel('y'), title(' ')
tikrinu=subs(L,X);
if tikrinu==Y
     disp('Interpoliavimo salygos tenkinamos')
 else
     disp('Interpoliavimo salygos netenkinamos, tikrinkite skaiciavimus')
end
 
% 2 eil?s 
clear all
X=[-2 0 1];
Y=[3 1 -3];
N=length(X);
disp('Reiksmiu lentele yra')
fprintf('**********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('**********************************\n')
for i=1:N
fprintf('|%2G|%14G|%14G|\n',i-1,X(i),Y(i)) 
end
fprintf('**********************************\n')
syms x %jei skaiciuojam daugianariu reiksmes tarpiniuose taskuose, tai sios komandos neprireikai
m=N-1;
for i=1:m
L=0; %Sudeciai
for k=1:i+1
    c=1; %Sandaugai
   for j=1:i+1
      if k~=j %Jei i nelygu j
         c=c*((x-X(j))/(X(k)-X(j))); %Daugianariai c, sudaryti is sandaugu 
      end 
   end
  L=expand(L+c*Y(k)); %Daugianario L galutinis realizavimas.
end
end
fprintf('%G eiles daugianaris',m)
pretty(L)
%Grafiskai 
figure,
ezplot(L,[X(1)-1,X(N)+2]), hold on, 
plot(X,Y,'bo','MarkerFaceColor','b'), hold off, 
xlabel(' x '), ylabel('y'), title(' ')
tikrinu=subs(L,X);
if tikrinu==Y
     disp('Interpoliavimo salygos tenkinamos')
 else
     disp('Interpoliavimo salygos netenkinamos, tikrinkite skaiciavimus')
end

% 3 eiles
clear all
X=[-2 0 1 2];
Y=[3 1 -3 -1];
N=length(X);
disp('Reiksmiu lentele yra')
fprintf('**********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('**********************************\n')
for i=1:N
fprintf('|%2G|%14G|%14G|\n',i-1,X(i),Y(i)) 
end
fprintf('**********************************\n')
syms x %jei skaiciuojam daugianariu reiksmes tarpiniuose taskuose, tai sios komandos neprireikai
m=N-1;
for i=1:m
L=0; %Sudeciai
for k=1:i+1
    c=1; %Sandaugai
   for j=1:i+1
      if k~=j %Jei i nelygu j
         c=c*((x-X(j))/(X(k)-X(j))); %Daugianariai c, sudaryti is sandaugu 
      end 
   end
  L=expand(L+c*Y(k)); %Daugianario L galutinis realizavimas.
end
end
fprintf('%G eiles daugianaris',m)
pretty(L)
%Grafiskai 
figure,
ezplot(L,[X(1)-1,X(N)+2]), hold on, 
plot(X,Y,'bo','MarkerFaceColor','b'), hold off, 
xlabel(' x '), ylabel('y'), title(' ')
tikrinu=subs(L,X);
if tikrinu==Y
     disp('Interpoliavimo salygos tenkinamos')
 else
     disp('Interpoliavimo salygos netenkinamos, tikrinkite skaiciavimus')
end
% 4 eiles
clear all
X=[-2 0 1 2 3];
Y=[3 1 -3 -1 13];
N=length(X);
disp('Reiksmiu lentele yra')
fprintf('**********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('**********************************\n')
for i=1:N
fprintf('|%2G|%14G|%14G|\n',i-1,X(i),Y(i)) 
end
fprintf('**********************************\n')
syms x %jei skaiciuojam daugianariu reiksmes tarpiniuose taskuose, tai sios komandos neprireikai
m=N-1;
for i=1:m
L=0; %Sudeciai
for k=1:i+1
    c=1; %Sandaugai
   for j=1:i+1
      if k~=j %Jei i nelygu j
         c=c*((x-X(j))/(X(k)-X(j))); %Daugianariai c, sudaryti is sandaugu 
      end 
   end
  L=expand(L+c*Y(k)); %Daugianario L galutinis realizavimas.
end
end
fprintf('%G eiles daugianaris',m)
pretty(L)
%Grafiskai 
figure,
ezplot(L,[X(1)-1,X(N)+2]), hold on, 
plot(X,Y,'bo','MarkerFaceColor','b'), hold off, 
xlabel(' x '), ylabel('y'), title(' ')