clear all
x=[-2 0 1 2 3];
y=[3 1 -3 -1 13];
M=length(x); %x(i) kiekis.  Zinoma galima ir tiesiogiai nurodyti.
N=M-1;  %Daugianario eile.
disp('Reiksmiu lentele yra')
fprintf('**********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('**********************************\n')
for i=1:M
fprintf('|%2G|%14G|%14G|\n',i-1,x(i),y(i)) 
end
fprintf('**********************************\n')
% Pirmiausia apskaiciuojami skirtuminiai santykiai, kur visi isreiskiami 
% per y(k): f(i+1,2)=>f(x(i),x(i+1))=(y(i)-y(i+1))/(x(i)-x(i+1)), kai i>=1, 
%yra pirmos eiles, 
%f(i+1,3)=>f(x(i),x(i+1),x(i+2))=(f(x(i),x(i+1))-f(x(i+1),x(i+2)))/(x(i)-x(i+1))
%yra antros eiles ir t.t.

for k=1:M
   f(k,1)=y(k); 
end 
for j=1:N
    for i=j:N
        f(i+1,j+1)=(f(i,j)-f(i+1,j))/(x(i+1-j)-x(i+1));  
    end
end

syms X
% Visu eiliu Daugianariu sudarymas:
L=y(1); %Sumavimui
     p=1;  %Daugybai     
 for i=1:N
  p=p*(X-x(i));%Niutono formuleje esancios sandaugos (x-x[1])...(x-x[N])   
   fprintf('%G eiles daugianaris',i)
  L=expand(L+f(i+1,i+1)*p);
  %Vaizdingiau
  pretty(L)
  figure,
  ezplot(L,[x(1),x(N)+2]), hold on, plot(x,y,'bo','MarkerFaceColor','b'), hold off, 
xlabel(' x '), ylabel('y'), title(' ')
 end   
 tikrinu=subs(L,x);
if tikrinu==y
     disp('Interpoliavimo salygos tenkinamos')
 else
     disp('Interpoliavimo salygos netenkinamos, tikrinkite skaiciavimus')
 end