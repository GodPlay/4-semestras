clear all
x=[2 6 10 14 18 22 26];
y=[175 150 125 75 25 2 0];
N=length(x);
disp('Reiksmiu lentele yra')
fprintf('*********************************\n')
fprintf('|i |             x|             y|\n')
fprintf('*********************************\n')
for i=1:N
fprintf('|%2G|%14f|%14f|\n',i-1,x(i),y(i)) 
end


taske=3; %Tarpinis taskas.
fprintf('****************************************************************************************\n')
 fprintf('|N |   Daugianario reiksme|Paklaida absoliutiniu didumu|          Pak+L|          Pak-L|\n') 
 fprintf('****************************************************************************************\n')
N=length(x);
%Cia naudoju Lagranzo interpoliacine formule
for i=1:N-1
L(i)=0; %Sumavimui
for k=1:i+1
    c(k)=1; %Daugybai
   for j=1:i+1
      if k~=j %jei k nelygu i
         c(k)=c(k)*((taske-x(j))/(x(k)-x(j)));  %Daugianariu c(taske) reiksmes 
   end 
   end
  
  L(i)=L(i)+c(k)*y(k); 
end
   pakl(i)=abs(168-L(i)) ;
   fprintf('|%2G|%22f|%28f|%15f|%15f|\n',i,L(i),pakl(i), L(i)+pakl(i),L(i)-pakl(i));
end
  fprintf('****************************************************************************************\n')